function nonm(){var o=Number(document.getElementById("task").value)
if(o>0){
    if(o%2==0){
        console.log("This is a even number : " + o)
    }
    else{console.log("this i s odd number : " + o)}
}
else{console.log("Give me positive number")};
}
